/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bärenspiel;

import java.net.URL;
import java.util.Arrays;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * FXML Controller class
 *
 * @author Harish
 */
public class SecondController implements Initializable {

    /**
     * Initializes the controller class.
     */
   
    int resultbaer=0;
    int resultathoehle=0;
    int[] wuerfel = new int[7];
  
     @FXML
    private TextField loesungBaer;

    @FXML
    private TextField loesungHoehle;
    @FXML
    private Label valHöhlen;

    @FXML
    private Label valBären;
    @FXML
    private Label wuerfelText;
    
    String guessBären;
    String guessHöhlen;
    @FXML
    private ImageView imageView1;
    @FXML
    private ImageView imageView5;
    @FXML
    private ImageView imageView4;
    @FXML
    private ImageView imageView3;
    @FXML
    private ImageView imageView2;

    @FXML
    void wuerfeln(ActionEvent event) {
        resultbaer=0;
        resultathoehle=0;

        for (int i = 0; i < 5; i++) {
            int zahl = (int) ((Math.random()) * 6 + 1);

            wuerfel[i] = zahl;

        }
        
         for(int zahl:wuerfel){
        if(zahl%2!=0){
            resultbaer+=7-zahl;
            resultathoehle++;
            
        }
         valBären.setText("");
        valHöhlen.setText("");
         loesungHoehle.setText("");
        loesungBaer.setText("");
        
       setText();
    }
    }

    public void setText() {
        imageView1.setImage(new Image("Bilder/" + wuerfel[0] + ".png"));
        imageView2.setImage(new Image("Bilder/" + wuerfel[1] + ".png"));
        imageView3.setImage(new Image("Bilder/" + wuerfel[2] + ".png"));
        imageView4.setImage(new Image("Bilder/" + wuerfel[3] + ".png"));
        imageView5.setImage(new Image("Bilder/" + wuerfel[4] + ".png"));

      
        wuerfelText.setText("Diese Zahlen wurden gewürfelt");
        
    }

   
   

    
 @FXML
    void result(ActionEvent event) {
        try {
         guessHöhlen = loesungHoehle.getText();
                guessBären = loesungBaer.getText();
                
 if (Integer.valueOf(guessHöhlen) == resultathoehle && Integer.valueOf(guessBären) != resultbaer) {
                    valHöhlen.setText("Richtig");
                    valBären.setText("Falsch");
                } else if (Integer.valueOf(guessHöhlen) != resultathoehle && Integer.valueOf(guessBären) == resultbaer) {
                    valHöhlen.setText("Falsch");
                    valBären.setText("Richtig");
                } else if (Integer.valueOf(guessHöhlen) == resultathoehle && Integer.valueOf(guessBären) == resultbaer) {
                    valBären.setText("Richtig");
                    valHöhlen.setText("Richtig");
                   
                } else {
                    valBären.setText("Falsch");
                    valHöhlen.setText("Falsch");
                }
            }catch (Exception e){
                
    
} 
    }
    @FXML
    private void resetText() {
       
       
        valBären.setText("");
        valHöhlen.setText("");
         loesungHoehle.setText("");
        loesungBaer.setText("");
         
        

    }
    @FXML
    private void showResult() {
       
      loesungHoehle.setText(""+resultathoehle);
        loesungBaer.setText(""+resultbaer);  

    }
                
            

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
